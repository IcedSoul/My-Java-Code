package getweb;
import java.io.*;
import java.net.URL;
import org.apache.http.client.HttpClient;
import org.apache.http.HttpEntity;  
import org.apache.http.HttpResponse;  
import org.apache.http.client.ClientProtocolException;  
import org.apache.http.client.HttpClient;  
import org.apache.http.client.methods.HttpGet;  
import org.apache.http.impl.client.DefaultHttpClient;  
public class getweb {
public static void main(String args[])
{
	String path;
	URL pageURL=new URL(path);
	InputStream stream=pageURL.openStream();
	HttpClient httpclient=new HttpClient();
	
	
}

}
